library("bio3d")
library("NACEN")

# DSSP program (standardized secondary structure allocation)
dsspfile <- "E:/NACEN/dssp-3.0.0.exe"
Net <- NACENConstructor(PDBFile='PTPN11_model.pdb', WeightType="none", exefile=dsspfile)
NetP <- NACENAnalyzer(Net$AM, Net$NodeWeights)
write.table(NetP$NetP, "NetP-0.txt", quote=FALSE, row.names=FALSE)

#RC
setwd("E:/NACEN/RC")
# Build a weightless network, analyze and calculate the network parameters and export them to the text document NetP-1:185
for(i in 1:277){
  add1 <- paste("PTPN11_model_", i, ".pdb", sep="")
  add2 <- paste("NetP_", i, ".txt", sep="")
  Net <- NACENConstructor(PDBFile=add1, WeightType="none", exefile=dsspfile)
  NetP <- NACENAnalyzer(Net$AM, Net$NodeWeights)
  write.table(NetP$NetP, add2, quote=FALSE, row.names=FALSE)
}

for(i in 1:277){
  add1 <- paste("WT_PTPN11_model_", i, ".pdb", sep="")
  add2 <- paste("WT_NetP_", i, ".txt", sep="")
  Net <- NACENConstructor(PDBFile=add1, WeightType="none", exefile=dsspfile)
  NetP <- NACENAnalyzer(Net$AM, Net$NodeWeights)
  write.table(NetP$NetP, add2, quote=FALSE, row.names=FALSE)
}

#NC
setwd("E:/NACEN/NC")
for(i in 1:236){
  add1 <- paste("PTPN11_model_", i, ".pdb", sep="")
  add2 <- paste("NetP_", i, ".txt", sep="")
  Net <- NACENConstructor(PDBFile=add1, WeightType="none", exefile=dsspfile)
  NetP <- NACENAnalyzer(Net$AM, Net$NodeWeights)
  write.table(NetP$NetP, add2, quote=FALSE, row.names=FALSE)
}

for(i in 1:236){
  add1 <- paste("WT_PTPN11_model_", i, ".pdb", sep="")
  add2 <- paste("WT_NetP_", i, ".txt", sep="")
  Net <- NACENConstructor(PDBFile=add1, WeightType="none", exefile=dsspfile)
  NetP <- NACENAnalyzer(Net$AM, Net$NodeWeights)
  write.table(NetP$NetP, add2, quote=FALSE, row.names=FALSE)
}