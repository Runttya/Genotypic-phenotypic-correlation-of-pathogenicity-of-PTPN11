library("xlsx")
library("ggplot2")
library("ggpubr")
library("gridExtra")
library("RColorBrewer")
library("patchwork")

setwd("SHP2/NACEN")
#RC
#区分疾病组
RC_mat <- read.xlsx("SHP2_data.xlsx",1)
head(RC_mat)
#   NUM POS SEQ protein_change cDNA_change      Type Domain Score        Si         MI       ΔΔG      RASA
# 1   1   2   T          p.T2I      c.5C>T RASopathy   <NA>     4 1.7203559 0.19447303  0.178354 95.007500
# 2   2  10   N         p.N10D     c.28A>G RASopathy  SH2_1     6 1.4419147 0.31591289  4.353530 13.753700
# 3   3  12   T         p.T12A     c.34A>G RASopathy  SH2_1     7 1.1196461 0.15424828  0.475647 36.936600
# 4   4  18   N         p.N18S     c.53A>G RASopathy  SH2_1     3 2.1819636 0.34615723 -0.176573 54.408800
# 5   5  35   K         p.K35E    c.103A>G RASopathy  SH2_1     5 1.3564694 0.26279907 -1.142700 51.944500
# 6   6  43   L         p.L43F    c.127C>T RASopathy  SH2_1     8 0.1726519 0.05485857  2.684760  0.141452

#RAS
RAS_mat <- subset(RC_mat,Type == "RASopathy")
head(RAS_mat)
#   NUM POS SEQ protein_change cDNA_change      Type Domain Score        Si         MI       ΔΔG      RASA
# 1   1   2   T          p.T2I      c.5C>T RASopathy   <NA>     4 1.7203559 0.19447303  0.178354 95.007500
# 2   2  10   N         p.N10D     c.28A>G RASopathy  SH2_1     6 1.4419147 0.31591289  4.353530 13.753700
# 3   3  12   T         p.T12A     c.34A>G RASopathy  SH2_1     7 1.1196461 0.15424828  0.475647 36.936600
# 4   4  18   N         p.N18S     c.53A>G RASopathy  SH2_1     3 2.1819636 0.34615723 -0.176573 54.408800
# 5   5  35   K         p.K35E    c.103A>G RASopathy  SH2_1     5 1.3564694 0.26279907 -1.142700 51.944500
# 6   6  43   L         p.L43F    c.127C>T RASopathy  SH2_1     8 0.1726519 0.05485857  2.684760  0.141452
ras_position <- RAS_mat$POS
ras_position
#  [1]   2  10  12  18  35  43  45  50  55  56  56  58  58  59  60  62  70  72  75  76  76  82  82  86  92  94  95  97 110 110 131 138 139 140
#  [35] 147 154 157 160 163 168 186 186 188 190 195 200 218 231 245 256 257 261 261 261 262 275 279 279 282 285 285 285 287 293 293 298 316 319
#  [69] 323 328 333 335 340 343 347 348 350 353 359 362 364 375 377 383 385 391 392 406 408 411 412 421 428 428 430 449 450 450 456 461 461 462
# [103] 468 470 476 484 491 491 503 506 510 510 516 527 532 543 548 550 557 559 559 560 562 566 566 566 572
ras_num <- RAS_mat$NUM
ras_num
#   [1]   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16  17  18  19  20  21  22  23  24  25  26  27  28  29  30  31  32  33  34
#  [35]  35  36  37  38  39  40  41  42  43  44  45  46  47  48  49  50  51  52  53  54  55  56  57  58  59  60  61  62  63  64  65  66  67  68
#  [69]  69  70  71  72  73  74  75  76  77  78  79  80  81  82  83  84  85  86  87  88  89  90  91  92  93  94  95  96  97  98  99 100 101 102
# [103] 103 104 105 106 107 108 109 110 111 112 113 114 115 116 117 118 119 120 121 122 123 124 125 126 127
setwd("RC")
#循环分别读取每个氨基酸网络导致RAS表型的位点的K、B、C值，计算该位点K、B、C的mean值
#实验组
mu_data <- NULL
for(i in ras_position){
  data_part <- NULL
  for(j in ras_num){
    filename <- paste("NetP_",j,".txt",sep="")
    file_data<- read.table(filename,header=T,sep=" ")
    data_part <- rbind(data_part,subset(file_data,Resid == i))
  }
  K <- mean(data_part[,5])
  B <- mean(data_part[,6])
  C <- mean(data_part[,7])
  line1 <- cbind(data_part[1,1:3],K,B,C)
  mu_data <- rbind(mu_data,line1)
}
head(mu_data,15)#可以查看同一位点突变（但突变成不同的氨基酸是否重合）
#           ID chain Resid         K            B            C
# 2    A:2:ILE     A     2  3.000000   591.000000 0.0001477564
# 10  A:10:ASN     A    10  2.000000     6.642857 0.0001335594
# 12  A:12:THR     A    12  3.000000   177.785030 0.0001336487
# 18  A:18:ASN     A    18  7.000000    92.509624 0.0001268195
# 35  A:35:LYS     A    35  2.000000   247.058764 0.0001337260
# 43  A:43:LEU     A    43 10.000000  2200.303129 0.0001509048
# 45  A:45:VAL     A    45 11.000000  2687.416667 0.0001440036
# 50  A:50:ALA     A    50  5.000000   626.545902 0.0001383487
# 55  A:55:LYS     A    55  8.000000  1684.989032 0.0001554302
# 56  A:56:ILE     A    56  9.992126 13327.486450 0.0001653800
# 561 A:56:ILE     A    56  9.992126 13327.486450 0.0001653800
# 58  A:58:ASN     A    58  6.968504 23480.109893 0.0001695907
# 581 A:58:ASN     A    58  6.968504 23480.109893 0.0001695907
# 59  A:59:THR     A    59  2.000000   229.410758 0.0001626496
# 60  A:60:GLY     A    60  3.960630 25007.248817 0.0001726222

#WT组（对照组）
control_data <- NULL
for(i in ras_position){
  data_part <- NULL
  for(j in ras_num){
    filename <- paste("WT_NetP_",j,".txt",sep="")
    file_data<- read.table(filename,header=T,sep=" ")
    data_part <- rbind(data_part,subset(file_data,Resid == i))
  }
  K <- mean(data_part[,5])
  B <- mean(data_part[,6])
  C <- mean(data_part[,7])
  line1 <- cbind(data_part[1,1:3],K,B,C)
  control_data <- rbind(control_data,line1)
}
head(control_data,15)
#           ID chain Resid  K            B            C
# 2    A:2:THR     A     2  3   591.000000 0.0001477560
# 10  A:10:ASN     A    10  2     6.642857 0.0001337618
# 12  A:12:THR     A    12  3   177.858584 0.0001338513
# 18  A:18:ASN     A    18  7    93.811897 0.0001269684
# 35  A:35:LYS     A    35  2   237.736591 0.0001340487
# 43  A:43:LEU     A    43 10  2225.350472 0.0001512178
# 45  A:45:VAL     A    45 11  2712.385294 0.0001442382
# 50  A:50:ALA     A    50  5   627.066991 0.0001386582
# 55  A:55:LYS     A    55  8  1698.676872 0.0001558609
# 56  A:56:ILE     A    56 10 13450.934078 0.0001658656
# 561 A:56:ILE     A    56 10 13450.934078 0.0001658656
# 58  A:58:ASN     A    58  7 23960.068747 0.0001702135
# 581 A:58:ASN     A    58  7 23960.068747 0.0001702135
# 59  A:59:THR     A    59  2     0.000000 0.0001631860
# 60  A:60:GLY     A    60  4 25492.046147 0.0001734312


#计算每个位点的Degree Centrality（K）、Betweenness Centrality（B）、Closeness Centrality（C）
#实验组-对照组
Degree <- scale(mu_data[,4]-control_data[,4])
Betweenness <- scale(mu_data[,5]-control_data[,5])
Closeness <- scale(mu_data[,6]-control_data[,6])
#合并数据
RAS_mat <- cbind(RAS_mat,Degree,Betweenness,Closeness)
head(RAS_mat)
# NUM POS SEQ protein_change cDNA_change      Type Domain Score        Si         MI       ΔΔG      RASA     Degree Betweenness  Closeness
# 1   1   2   T          p.T2I      c.5C>T RASopathy   <NA>     4 1.7203559 0.19447303  0.178354 95.007500 -0.0111473  0.05047757  0.6266855
# 2   2  10   N         p.N10D     c.28A>G RASopathy  SH2_1     6 1.4419147 0.31591289  4.353530 13.753700 -0.0111473  0.05047757 -0.7424476
# 3   3  12   T         p.T12A     c.34A>G RASopathy  SH2_1     7 1.1196461 0.15424828  0.475647 36.936600 -0.0111473  0.04966134 -0.7442245
# 4   4  18   N         p.N18S     c.53A>G RASopathy  SH2_1     3 2.1819636 0.34615723 -0.176573 54.408800 -0.0111473  0.03602627 -0.3815926
# 5   5  35   K         p.K35E    c.103A>G RASopathy  SH2_1     5 1.3564694 0.26279907 -1.142700 51.944500 -0.0111473  0.15392553 -1.5556249
# 6   6  43   L         p.L43F    c.127C>T RASopathy  SH2_1     8 0.1726519 0.05485857  2.684760  0.141452 -0.0111473 -0.22747229 -1.4904131

#Cancer
CAN_mat <- subset(RC_mat,Type == "CANCER")
head(CAN_mat)
#     NUM POS SEQ protein_change cDNA_change   Type Domain Score        Si         MI        ΔΔG      RASA
# 128 128   6   W          p.W6C     c.18G>T CANCER  SH2_1     7 0.0969861 0.08038977  4.4844700  0.657588
# 129 129  14   V         p.V14M     c.40G>A CANCER  SH2_1     3 1.7290894 0.29151016 -0.6722150 69.758600
# 130 130  16   A         p.A16T     c.46G>A CANCER  SH2_1     9 0.1268547 0.04265571  4.4669700  0.000000
# 131 131  16   A         p.A16V     c.47C>T CANCER  SH2_1     9 0.1268547 0.04265571  3.2919100  0.000000
# 132 132  25   V         p.V25I     c.73G>A CANCER  SH2_1     4 1.6669482 0.28408907  0.0116869 57.417600
# 133 133  33   P         p.P33S     c.97C>T CANCER  SH2_1     9 0.1268547 0.04931259  3.6261600 11.073300
can_position <- CAN_mat$POS
can_position
#  [1]   6  14  16  16  25  33  37  38  44  45  46  52  53  54  58  58  60  60  60  60  61  61  61  61  61  61  61  61  63  64  68  69  69  69
#  [35]  69  69  69  70  71  71  71  71  72  72  72  72  72  72  73  73  74  74  76  76  76  76  76  76  76  76  77  78  79  80  82  85  91  95
#  [69]  98  99 101 101 106 107 107 110 115 116 122 123 126 133 133 133 138 139 139 149 163 176 176 177 180 186 189 189 192 196 201 220 223 226
# [103] 231 265 278 288 289 289 306 308 309 323 355 356 357 384 391 392 401 409 414 419 425 425 425 426 428 437 437 438 444 444 449 454 461 462
# [137] 464 464 464 465 468 483 490 491 497 498 499 502 502 502 503 503 503 503 503 503 504 504 505 506 507 507 507 510 510 510 510 510 512 522
# [171] 527 530 539 541 548 556 556 561 561 565 590

can_num <- CAN_mat$NUM
can_num
#   [1] 128 129 130 131 132 133 134 135 136 137 138 139 140 141 142 143 144 145 146 147 148 149 150 151 152 153 154 155 156 157 158 159 160 161
#  [35] 162 163 164 165 166 167 168 169 170 171 172 173 174 175 176 177 178 179 180 181 182 183 184 185 186 187 188 189 190 191 192 193 194 195
#  [69] 196 197 198 199 200 201 202 203 204 205 206 207 208 209 210 211 212 213 214 215 216 217 218 219 220 221 222 223 224 225 226 227 228 229
# [103] 230 231 232 233 234 235 236 237 238 239 240 241 242 243 244 245 246 247 248 249 250 251 252 253 254 255 256 257 258 259 260 261 262 263
# [137] 264 265 266 267 268 269 270 271 272 273 274 275 276 277 278 279 280 281 282 283 284 285 286 287 288 289 290 291 292 293 294 295 296 297
# [171] 298 299 300 301 302 303 304 305 306 307 308

#循环分别读取每个氨基酸网络导致RAS表型的位点的K、B、C值，计算该位点K、B、C的mean值
#实验组
mu_data <- NULL
for(i in can_position){
  data_part <- NULL
  for(j in can_num){
    filename <- paste("NetP_",j,".txt",sep="")
    file_data<- read.table(filename,header=T,sep=" ")
    data_part <- rbind(data_part,subset(file_data,Resid == i))
  }
  K <- mean(data_part[,5])
  B <- mean(data_part[,6])
  C <- mean(data_part[,7])
  line1 <- cbind(data_part[1,1:3],K,B,C)
  mu_data <- rbind(mu_data,line1)
}
head(mu_data)
#           ID chain Resid        K          B            C
# 6    A:6:CYS     A     6 9.005525 6460.97363 0.0001533722
# 14  A:14:VAL     A    14 5.988950   24.21655 0.0001254711
# 16  A:16:ALA     A    16 8.022099 2342.20468 0.0001353752
# 161 A:16:ALA     A    16 8.022099 2342.20468 0.0001353752
# 25  A:25:VAL     A    25 3.011050  646.47329 0.0001320027
# 33  A:33:PRO     A    33 4.000000  241.31862 0.0001491905
#WT组（对照组）
control_data <- NULL
for(i in can_position){
  data_part <- NULL
  for(j in can_num){
    filename <- paste("WT_NetP_",j,".txt",sep="")
    file_data<- read.table(filename,header=T,sep=" ")
    data_part <- rbind(data_part,subset(file_data,Resid == i))
  }
  K <- mean(data_part[,5])
  B <- mean(data_part[,6])
  C <- mean(data_part[,7])
  line1 <- cbind(data_part[1,1:3],K,B,C)
  control_data <- rbind(control_data,line1)
}
head(control_data)
#           ID chain Resid K          B            C
# 6    A:6:TRP     A     6 9 6328.56930 0.0001533507
# 14  A:14:VAL     A    14 6   24.40566 0.0001254705
# 16  A:16:ALA     A    16 8 2356.08728 0.0001353730
# 161 A:16:ALA     A    16 8 2356.08728 0.0001353730
# 25  A:25:VAL     A    25 3  644.57894 0.0001318044
# 33  A:33:PRO     A    33 4  239.96495 0.0001494322
#计算每个位点的Degree Centrality（K）、Betweenness Centrality（B）、Closeness Centrality（C）
#实验组-对照组
Degree <- scale(mu_data[,4]-control_data[,4])
Betweenness <- scale(mu_data[,5]-control_data[,5])
Closeness <- scale(mu_data[,6]-control_data[,6])
#合并数据
CAN_mat <- cbind(CAN_mat,Degree,Betweenness,Closeness)
head(CAN_mat)
#     NUM POS SEQ protein_change cDNA_change   Type Domain Score        Si         MI        ΔΔG      RASA      Degree  Betweenness  Closeness
# 128 128   6   W          p.W6C     c.18G>T CANCER  SH2_1     7 0.0969861 0.08038977  4.4844700  0.657588 -0.39603401  0.428704906 -0.2791669
# 129 129  14   V         p.V14M     c.40G>A CANCER  SH2_1     3 1.7290894 0.29151016 -0.6722150 69.758600 -0.81522791 -0.014890150 -0.3584587
# 130 130  16   A         p.A16T     c.46G>A CANCER  SH2_1     9 0.1268547 0.04265571  4.4669700  0.000000  0.02315988 -0.060702091 -0.3520182
# 131 131  16   A         p.A16V     c.47C>T CANCER  SH2_1     9 0.1268547 0.04265571  3.2919100  0.000000  0.02315988 -0.060702091 -0.3520182
# 132 132  25   V         p.V25I     c.73G>A CANCER  SH2_1     4 1.6669482 0.28408907  0.0116869 57.417600 -0.25630271 -0.007919871  0.3916606
# 133 133  33   P         p.P33S     c.97C>T CANCER  SH2_1     9 0.1268547 0.04931259  3.6261600 11.073300 -0.53576531 -0.009728734 -1.2771127

#将两种表型的表合并，进行差异分析及可视化
RC_mat <- rbind(RAS_mat,CAN_mat)
#将Type列转为factor型
RC_mat$Type <- as.factor(RC_mat$Type)
#查看数据
str(RC_mat)
# 'data.frame': 308 obs. of  15 variables:
#  $ NUM           : num  1 2 3 4 5 6 7 8 9 10 ...
#  $ POS           : num  2 10 12 18 35 43 45 50 55 56 ...
#  $ SEQ           : chr  "T" "N" "T" "N" ...
#  $ protein_change: chr  "p.T2I" "p.N10D" "p.T12A" "p.N18S" ...
#  $ cDNA_change   : chr  "c.5C>T" "c.28A>G" "c.34A>G" "c.53A>G" ...
#  $ Type          : Factor w/ 2 levels "CANCER","RASopathy": 2 2 2 2 2 2 2 2 2 2 ...
#  $ Domain        : chr  NA "SH2_1" "SH2_1" "SH2_1" ...
#  $ Score         : num  4 6 7 3 5 8 9 4 8 9 ...
#  $ Si            : num  1.72 1.44 1.12 2.18 1.36 ...
#  $ MI            : num  0.194 0.316 0.154 0.346 0.263 ...
#  $ ΔΔG           : num  0.178 4.354 0.476 -0.177 -1.143 ...
#  $ RASA          : num  95 13.8 36.9 54.4 51.9 ...
#  $ Degree        : num  -0.0111 -0.0111 -0.0111 -0.0111 -0.0111 ...
#  $ Betweenness   : num  0.0505 0.0505 0.0497 0.036 0.1539 ...
#  $ Closeness     : num  0.627 -0.742 -0.744 -0.382 -1.556 ...


#保存数据
write.xlsx(RC_mat, "SHP2_data1.xlsx",sheetName = "RC",append = TRUE)
#将数据整合进"SHP2_data.xlsx"

#添加RAS各组间的比较
RC_comparisons<-list(c("RASopathy","CANCER"))
#绘制Degree提琴图
p1 <- ggviolin(RC_mat, x="Type", y="Degree", fill ="Type", add = "boxplot", add.params = list(fill="Type"))+ 
        stat_compare_means(comparisons = RC_comparisons)+ 
        xlab("Type")+
        ylab("Degree")+
        guides(fill="none")+
        theme(axis.text.x =element_text(size = 10),
              axis.text.y =element_text(size = 15),
              axis.title.y = element_text(size = 20))
p1
#绘制Betweenness提琴图
p2 <- ggviolin(RC_mat, x="Type", y="Betweenness", fill ="Type", add = "boxplot", add.params = list(fill="Type"))+ 
        stat_compare_means(comparisons = RC_comparisons)+ 
        xlab("Type")+
        ylab("Betweenness")+
        guides(fill="none")+
        theme(axis.text.x =element_text(size = 10),
              axis.text.y =element_text(size = 15),
              axis.title.y = element_text(size = 20))
p2
#绘制Closeness提琴图
p3 <- ggviolin(RC_mat, x="Type", y="Closeness", fill ="Type", add = "boxplot", add.params = list(fill="Type"))+ 
        stat_compare_means(comparisons = RC_comparisons)+ 
        xlab("Type")+
        ylab("Closeness")+
        guides(fill="none")+
        theme(axis.text.x =element_text(size = 10),
              axis.text.y =element_text(size = 15),
              axis.title.y = element_text(size = 20))
p3
#绘制Degree柱状图
p4 <- ggplot(RC_mat,aes(POS,Degree,fill = Type))+
        geom_bar(stat = 'identity',position="dodge")+
        theme(
          legend.position = c(.9, .1),
          legend.justification = c("right", "bottom"),
          legend.background = element_blank(),
          legend.key = element_blank()
          )
p4
#绘制Betweenness柱状图
p5 <- ggplot(RC_mat,aes(POS,Betweenness,fill = Type))+
        geom_bar(stat = 'identity',position="dodge")+
        theme(
          legend.position = c(.9, .1),
          legend.justification = c("right", "bottom"),
          legend.background = element_blank(),
          legend.key = element_blank()
          )
p5
#绘制Closeness柱状图
p6 <- ggplot(RC_mat,aes(POS,Closeness,fill = Type))+
        geom_bar(stat = 'identity',position="dodge")+
        theme(
          legend.position = c(.9, .1),
          legend.justification = c("right", "bottom"),
          legend.background = element_blank(),
          legend.key = element_blank()
          )
p6

#patchwork
p4/p5/p6/(p1+p2+p3)+
plot_layout(heights =c(1,1,1,2),widths = c(1,1,1))+
plot_annotation(tag_levels = "A")

#########################################################################################################################
#########################################################################################################################
#########################################################################################################################
#########################################################################################################################
#########################################################################################################################

#NC
#区分疾病组
setwd("SHP2/NACEN")
NC_mat <- read.xlsx("SHP2_data.xlsx",3)
head(NC_mat)
# NUM POS SEQ protein_change cDNA_change            Type Domain conservation       Si         MI        ΔΔG    RASA
# 1   1   6   W          p.W6C     c.18G>T          CANCER  SH2_1            8 0.155734 0.09718931  4.9536800  5.0277
# 2   2  14   V         p.V14M     c.40G>A          CANCER  SH2_1            1 1.914535 0.29010438 -0.7278360 64.8680
# 3   3  16   A         p.A16T     c.46G>A          CANCER  SH2_1            9 0.112226 0.05770824  3.1940400  0.0000
# 4   4  16   A         p.A16V     c.47C>T          CANCER  SH2_1            9 0.112226 0.05770824  2.5622100  0.0000
# 5   5  18   N         p.N18S     c.53A>G Noonan syndrome  SH2_1            1 2.339767 0.31286182 -0.0223163 54.9350
# 6   6  22   T         p.T22A     c.64A>G Noonan syndrome  SH2_1            1 1.884269 0.29118789  0.0129759 76.6060

#NS
NS_mat <- subset(NC_mat,Type == "Noonan syndrome")
head(NS_mat)
#    NUM POS SEQ protein_change cDNA_change            Type Domain conservation        Si         MI        ΔΔG     RASA
# 5    5  18   N         p.N18S     c.53A>G Noonan syndrome  SH2_1            1 2.3397675 0.31286182 -0.0223163 54.93500
# 6    6  22   T         p.T22A     c.64A>G Noonan syndrome  SH2_1            1 1.8842691 0.29118789  0.0129759 76.60600
# 17  17  56   I         p.I56V    c.166A>G Noonan syndrome  SH2_1            9 0.2728006 0.07999856  1.2198300  0.51246
# 18  18  56   I         p.I56T    c.167T>C Noonan syndrome  SH2_1            9 0.2728006 0.07999856  4.0029800  0.51246
# 19  19  57   Q         p.Q57H    c.171G>T Noonan syndrome  SH2_1            7 0.5245452 0.15976025 -0.0762566 41.98000
# 24  24  58   N         p.N58H    c.172A>C Noonan syndrome  SH2_1            8 0.4697554 0.14069922  7.3004200  7.67330
ns_position <- NS_mat$POS
ns_position
# [1]  18  22  56  56  57  58  58  60  60  62  70  72  73  76  76  79 106 109 110 110 129 131 132 158 163 186 200 221 256 258
# [31] 258 261 262 268 275 276 279 282 285 285 285 285 287 293 314 320 350 392 411 424 426 454 461 468 468 470 491 491 491 500
# [61] 510 510
ns_num <- NS_mat$NUM
ns_num
#  [1]   5   6  17  18  19  24  25  29  30  40  49  60  63  74  75  80  90  94  95  96 104 105 106 113 114 122 127 131 135 136
# [31] 137 138 139 140 141 142 144 145 146 147 148 149 150 154 158 159 161 170 173 176 181 191 193 199 200 201 206 207 208 212
# [61] 229 230
setwd("NC")
#循环分别读取每个氨基酸网络导致NS表型的位点的K、B、C值，计算该位点K、B、C的mean值
#实验组
mu_data <- NULL
for(i in ns_position){
  data_part <- NULL
  for(j in ns_num){
    filename <- paste("NetP_",j,".txt",sep="")
    file_data<- read.table(filename,header=T,sep=" ")
    data_part <- rbind(data_part,subset(file_data,Resid == i))
  }
  K <- mean(data_part[,5])
  B <- mean(data_part[,6])
  C <- mean(data_part[,7])
  line1 <- cbind(data_part[1,1:3],K,B,C)
  mu_data <- rbind(mu_data,line1)
}
head(mu_data,10)#可以查看同一位点突变（但突变成不同的氨基酸是否重合）
#           ID chain Resid        K            B            C
# 16  A:18:SER     A    18 7.000000 5.290107e+01 0.0001770490
# 20  A:22:THR     A    22 5.000000 8.428571e-01 0.0001742669
# 54  A:56:ILE     A    56 9.000000 4.313095e+03 0.0002243044
# 541 A:56:ILE     A    56 9.000000 4.313095e+03 0.0002243044
# 55  A:57:GLN     A    57 7.016129 8.287605e+03 0.0002337836
# 56  A:58:ASN     A    58 2.064516 7.129929e+03 0.0002313326
# 561 A:58:ASN     A    58 2.064516 7.129929e+03 0.0002313326
# 58  A:60:GLY     A    60 2.951613 1.137646e+04 0.0002479473
# 581 A:60:GLY     A    60 2.951613 1.137646e+04 0.0002479473
# 60  A:62:TYR     A    62 3.967742 3.535006e+03 0.0002336082

#WT组（对照组）
control_data <- NULL
for(i in ns_position){
  data_part <- NULL
  for(j in ns_num){
    filename <- paste("WT_NetP_",j,".txt",sep="")
    file_data<- read.table(filename,header=T,sep=" ")
    data_part <- rbind(data_part,subset(file_data,Resid == i))
  }
  K <- mean(data_part[,5])
  B <- mean(data_part[,6])
  C <- mean(data_part[,7])
  line1 <- cbind(data_part[1,1:3],K,B,C)
  control_data <- rbind(control_data,line1)
}
head(control_data,10)
#           ID chain Resid K            B            C
# 16  A:18:ASN     A    18 7 5.326216e+01 0.0001770538
# 20  A:22:THR     A    22 5 8.428571e-01 0.0001742160
# 54  A:56:ILE     A    56 9 4.159299e+03 0.0002245173
# 541 A:56:ILE     A    56 9 4.159299e+03 0.0002245173
# 55  A:57:GLN     A    57 7 8.571442e+03 0.0002346867
# 56  A:58:ASN     A    58 2 7.570042e+03 0.0002333178
# 561 A:58:ASN     A    58 2 7.570042e+03 0.0002333178
# 58  A:60:GLY     A    60 3 1.193204e+04 0.0002514458
# 581 A:60:GLY     A    60 3 1.193204e+04 0.0002514458
# 60  A:62:TYR     A    62 4 3.761965e+03 0.0002348520


#计算每个位点的Degree Centrality（K）、Betweenness Centrality（B）、Closeness Centrality（C）
#实验组-对照组
Degree <- scale(mu_data[,4]-control_data[,4])
Betweenness <- scale(mu_data[,5]-control_data[,5])
Closeness <- scale(mu_data[,6]-control_data[,6])
#合并数据
NS_mat <- cbind(NS_mat,Degree,Betweenness,Closeness)
head(NS_mat)
#    NUM POS SEQ protein_change cDNA_change            Type Domain conservation        Si         MI        ΔΔG     RASA
# 5    5  18   N         p.N18S     c.53A>G Noonan syndrome  SH2_1            1 2.3397675 0.31286182 -0.0223163 54.93500
# 6    6  22   T         p.T22A     c.64A>G Noonan syndrome  SH2_1            1 1.8842691 0.29118789  0.0129759 76.60600
# 17  17  56   I         p.I56V    c.166A>G Noonan syndrome  SH2_1            9 0.2728006 0.07999856  1.2198300  0.51246
# 18  18  56   I         p.I56T    c.167T>C Noonan syndrome  SH2_1            9 0.2728006 0.07999856  4.0029800  0.51246
# 19  19  57   Q         p.Q57H    c.171G>T Noonan syndrome  SH2_1            7 0.5245452 0.15976025 -0.0762566 41.98000
# 24  24  58   N         p.N58H    c.172A>C Noonan syndrome  SH2_1            8 0.4697554 0.14069922  7.3004200  7.67330
#        Degree Betweenness  Closeness
# 5  -0.1553585   0.1990137  0.2772289
# 6  -0.1553585   0.2011992  0.3423167
# 17 -0.1553585   1.1320145  0.0340469
# 18 -0.1553585   1.1320145  0.0340469
# 19  0.2299305  -1.5166659 -0.7726627
# 24  1.3857976  -2.4624957 -2.0373382

#Cancer
CAN_mat <- subset(NC_mat,Type == "CANCER")
head(CAN_mat)
#   NUM POS SEQ protein_change cDNA_change   Type Domain conservation        Si         MI         ΔΔG    RASA
# 1   1   6   W          p.W6C     c.18G>T CANCER  SH2_1            8 0.1557340 0.09718931  4.95368000  5.0277
# 2   2  14   V         p.V14M     c.40G>A CANCER  SH2_1            1 1.9145353 0.29010438 -0.72783600 64.8680
# 3   3  16   A         p.A16T     c.46G>A CANCER  SH2_1            9 0.1122260 0.05770824  3.19404000  0.0000
# 4   4  16   A         p.A16V     c.47C>T CANCER  SH2_1            9 0.1122260 0.05770824  2.56221000  0.0000
# 7   7  25   V         p.V25I     c.73G>A CANCER  SH2_1            1 1.9693275 0.30174183 -0.00818497 56.7380
# 8   8  33   P         p.P33S     c.97C>T CANCER  SH2_1            8 0.2890237 0.09279083  2.81931000 13.9110
can_position <- CAN_mat$POS
can_position
#  [1]   6  14  16  16  25  33  37  38  44  45  46  52  53  54  58  58  58  58  60  60  60  60  61  61  61  61  61  61  61
#  [30]  61  62  64  68  69  69  69  69  70  71  71  71  71  71  72  72  72  72  72  72  73  73  74  74  76  76  76  76  76
#  [59]  76  76  76  77  78  79  80  82  85  91  95  98  99 101 101 106 107 107 110 115 116 122 123 123 126 133 133 133 138
#  [88] 139 149 163 173 176 176 177 180 186 189 189 192 196 201 220 220 223 226 231 278 288 289 289 306 309 311 323 351 355
# [117] 356 357 382 384 391 392 401 409 414 419 425 425 425 426 428 437 437 438 443 444 444 449 454 461 462 464 464 464 465
# [146] 483 485 490 491 497 498 498 500 502 502 502 503 503 503 503 503 503 503 504 505 506 507 507 510 510 510 510 512 522
can_num <- CAN_mat$NUM
can_num
#   [1]   1   2   3   4   7   8   9  10  11  12  13  14  15  16  20  21  22  23  26  27  28  31  32  33  34  35  36  37  38
#  [30]  39  41  42  43  44  45  46  47  48  50  51  52  53  54  55  56  57  58  59  61  62  64  65  66  67  68  69  70  71
#  [59]  72  73  76  77  78  79  81  82  83  84  85  86  87  88  89  91  92  93  97  98  99 100 101 102 103 107 108 109 110
#  [88] 111 112 115 116 117 118 119 120 121 123 124 125 126 128 129 130 132 133 134 143 151 152 153 155 156 157 160 162 163
# [117] 164 165 166 167 168 169 171 172 174 175 177 178 179 180 182 183 184 185 186 187 188 189 190 192 194 195 196 197 198
# [146] 202 203 204 205 209 210 211 213 214 215 216 217 218 219 220 221 222 223 224 225 226 227 228 231 232 233 234 235 236

#循环分别读取每个氨基酸网络导致RAS表型的位点的K、B、C值，计算该位点K、B、C的mean值
#实验组
mu_data <- NULL
for(i in can_position){
  data_part <- NULL
  for(j in can_num){
    filename <- paste("NetP_",j,".txt",sep="")
    file_data<- read.table(filename,header=T,sep=" ")
    data_part <- rbind(data_part,subset(file_data,Resid == i))
  }
  K <- mean(data_part[,5])
  B <- mean(data_part[,6])
  C <- mean(data_part[,7])
  line1 <- cbind(data_part[1,1:3],K,B,C)
  mu_data <- rbind(mu_data,line1)
}
head(mu_data,10)
#           ID chain Resid         K          B            C
# 4    A:6:CYS     A     6  9.005747 8028.66528 0.0002304656
# 12  A:14:VAL     A    14  5.988506   23.07044 0.0001735126
# 14  A:16:ALA     A    16  8.005747 1545.91650 0.0001904679
# 141 A:16:ALA     A    16  8.005747 1545.91650 0.0001904679
# 23  A:25:VAL     A    25  3.011494  598.50107 0.0001908462
# 31  A:33:PRO     A    33  4.000000 1408.81267 0.0002110464
# 35  A:37:ASN     A    37  2.000000  145.18733 0.0001681041
# 36  A:38:PRO     A    38  2.000000  660.18733 0.0001840394
# 42  A:44:SER     A    44 11.000000  915.35769 0.0002094535
# 43  A:45:VAL     A    45 11.000000 1763.35034 0.0002059195

#WT组（对照组）
control_data <- NULL
for(i in can_position){
  data_part <- NULL
  for(j in can_num){
    filename <- paste("WT_NetP_",j,".txt",sep="")
    file_data<- read.table(filename,header=T,sep=" ")
    data_part <- rbind(data_part,subset(file_data,Resid == i))
  }
  K <- mean(data_part[,5])
  B <- mean(data_part[,6])
  C <- mean(data_part[,7])
  line1 <- cbind(data_part[1,1:3],K,B,C)
  control_data <- rbind(control_data,line1)
}
head(control_data,10)
#           ID chain Resid  K         B            C
# 4    A:6:TRP     A     6  9 8061.4970 0.0002301496
# 12  A:14:VAL     A    14  6   23.2718 0.0001734004
# 14  A:16:ALA     A    16  8 1564.3949 0.0001903312
# 141 A:16:ALA     A    16  8 1564.3949 0.0001903312
# 23  A:25:VAL     A    25  3  598.0466 0.0001902588
# 31  A:33:PRO     A    33  4 1406.3085 0.0002109705
# 35  A:37:ASN     A    37  2  147.6915 0.0001680955
# 36  A:38:PRO     A    38  2  662.6915 0.0001840265
# 42  A:44:SER     A    44 11  875.6329 0.0002082899
# 43  A:45:VAL     A    45 11 1806.3407 0.0002057613

#计算每个位点的Degree Centrality（K）、Betweenness Centrality（B）、Closeness Centrality（C）
#实验组-对照组
Degree <- scale(mu_data[,4]-control_data[,4])
Betweenness <- scale(mu_data[,5]-control_data[,5])
Closeness <- scale(mu_data[,6]-control_data[,6])
#合并数据
CAN_mat <- cbind(CAN_mat,Degree,Betweenness,Closeness)
head(CAN_mat)
#   NUM POS SEQ protein_change cDNA_change   Type Domain conservation        Si         MI         ΔΔG    RASA     Degree
# 1   1   6   W          p.W6C     c.18G>T CANCER  SH2_1            8 0.1557340 0.09718931  4.95368000  5.0277 -0.4099176
# 2   2  14   V         p.V14M     c.40G>A CANCER  SH2_1            1 1.9145353 0.29010438 -0.72783600 64.8680 -0.8003865
# 3   3  16   A         p.A16T     c.46G>A CANCER  SH2_1            9 0.1122260 0.05770824  3.19404000  0.0000 -0.4099176
# 4   4  16   A         p.A16V     c.47C>T CANCER  SH2_1            9 0.1122260 0.05770824  2.56221000  0.0000 -0.4099176
# 7   7  25   V         p.V25I     c.73G>A CANCER  SH2_1            1 1.9693275 0.30174183 -0.00818497 56.7380 -0.2797612
# 8   8  33   P         p.P33S     c.97C>T CANCER  SH2_1            8 0.2890237 0.09279083  2.81931000 13.9110 -0.5400739
#   Betweenness  Closeness
# 1 -0.14648392 -0.2382018
# 2 -0.02889469 -0.5780459
# 3 -0.09475923 -0.5372381
# 4 -0.09475923 -0.5372381
# 7 -0.02653127  0.2145002
# 8 -0.01914490 -0.6385685

#将两种表型的表合并，进行差异分析及可视化
NC_mat <- rbind(NS_mat,CAN_mat)
#将Type列转为factor型
NC_mat$Type <- as.factor(NC_mat$Type)
#查看数据
str(NC_mat)
# 'data.frame': 236 obs. of  15 variables:
#  $ NUM           : num  5 6 17 18 19 24 25 29 30 40 ...
#  $ POS           : num  18 22 56 56 57 58 58 60 60 62 ...
#  $ SEQ           : chr  "N" "T" "I" "I" ...
#  $ protein_change: chr  "p.N18S" "p.T22A" "p.I56V" "p.I56T" ...
#  $ cDNA_change   : chr  "c.53A>G" "c.64A>G" "c.166A>G" "c.167T>C" ...
#  $ Type          : Factor w/ 2 levels "CANCER","Noonan syndrome": 2 2 2 2 2 2 2 2 2 2 ...
#  $ Domain        : chr  "SH2_1" "SH2_1" "SH2_1" "SH2_1" ...
#  $ conservation  : num  1 1 9 9 7 8 8 8 8 2 ...
#  $ Si            : num  2.34 1.884 0.273 0.273 0.525 ...
#  $ MI            : num  0.313 0.291 0.08 0.08 0.16 ...
#  $ ΔΔG           : num  -0.0223 0.013 1.2198 4.003 -0.0763 ...
#  $ RASA          : num  54.935 76.606 0.512 0.512 41.98 ...
#  $ Degree        : num  -0.155 -0.155 -0.155 -0.155 0.23 ...
#  $ Betweenness   : num  0.199 0.201 1.132 1.132 -1.517 ...
#  $ Closeness     : num  0.277 0.342 0.034 0.034 -0.773 ...


#保存数据
write.xlsx(NC_mat, "SHP2_data1.xlsx",sheetName = "NC",append = TRUE)

#添加NS各组间的比较
NC_comparisons<-list(c("Noonan syndrome","CANCER"))
#绘制Degree提琴图
ggviolin(NC_mat, x="Type", y="Degree", fill ="Type", add = "boxplot", add.params = list(fill="Type"))+ 
  stat_compare_means(comparisons = NC_comparisons)+ 
  xlab("Type")+
  ylab("Degree")+
  guides(fill="none")+
  theme(axis.text.x =element_text(size = 10),
        axis.text.y =element_text(size = 15),
        axis.title.y = element_text(size = 20))
#绘制Betweenness提琴图
ggviolin(NC_mat, x="Type", y="Betweenness", fill ="Type", add = "boxplot", add.params = list(fill="Type"))+ 
  stat_compare_means(comparisons = NC_comparisons)+ 
  xlab("Type")+
  ylab("Betweenness")+
  guides(fill="none")+
  theme(axis.text.x =element_text(size = 10),
        axis.text.y =element_text(size = 15),
        axis.title.y = element_text(size = 20))
#绘制Closeness提琴图
ggviolin(NC_mat, x="Type", y="Closeness", fill ="Type", add = "boxplot", add.params = list(fill="Type"))+ 
  stat_compare_means(comparisons = NC_comparisons)+ 
  xlab("Type")+
  ylab("Closeness")+
  guides(fill="none")+
  theme(axis.text.x =element_text(size = 10),
        axis.text.y =element_text(size = 15),
        axis.title.y = element_text(size = 20))
#绘制Degree柱状图
ggplot(NC_mat,aes(POS,Degree,fill = Type))+
  geom_bar(stat = 'identity')+
  theme(legend.position = "top")
#绘制Betweenness柱状图
ggplot(NC_mat,aes(POS,Betweenness,fill = Type))+
  geom_bar(stat = 'identity')+
  theme(legend.position = "top")
#绘制Closeness柱状图
ggplot(NC_mat,aes(POS,Closeness,fill = Type))+
  geom_bar(stat = 'identity')+
  theme(legend.position = "top")












