# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
from pandas import Series,DataFrame
"构建突变信息表格"
fileNameStr = 'mutation.xlsx'
xl = pd.ExcelFile(fileNameStr)
mu_dat = xl.parse('Sheet2')
print(mu_dat)
"处理Name列"
NM = list()
a_mutation = list()
p_mutation = list()
disease = list()
df1 = DataFrame()
for i in range(0,mu_dat.count()[1]):
    str1 = mu_dat.values[i][0]
    strlist = str1.split("(")
    "添加染色体序号"
    NM.append(strlist[0])
    "添加氨基酸突变位点"
    aamu = strlist[1].split(":")[1]
    a_mutation.append(aamu)
    "添加蛋白质突变"
    pmu = strlist[2].split(")")[0]
    p_mutation.append(pmu)
    "添加疾病"
    str2 = mu_dat["Condition(s)"][i]
    diseaselist = str2.split("|")
    disease.append(diseaselist)
    df2=DataFrame({'disease':diseaselist,'aamutation':(aamu*len(diseaselist)).split()})
    df1 = df1.append(df2)

df1.to_excel('aamutation_disease.xlsx', sheet_name='Sheet1',index=False)

dic = {
       "aamutation": a_mutation,
       "NMID":NM,
       "Protein.change": p_mutation,
       "Accession":list(mu_dat["Accession"]),
       "Clinical significance (Last reviewed)":list(mu_dat["Clinical significance (Last reviewed)"]),
       "dbSNP ID":list(mu_dat["dbSNP ID"]),
       "Disease":list(mu_dat["Condition(s)"])
       }
df2 = pd.DataFrame(dic) # 创建Dataframe
df2.to_excel('mutation_inf.xlsx', sheet_name='Sheet1',index=False)

def getlistnum(li):#这个函数就是要对列表的每个元素进行计数
     set1 = set(li)
     dict1 = {}
     for item in set1:
         dict1.update({item:li.count(item)})
     return dict1

res = getlistnum(list(df1["disease"]))

pf = pd.Series(res)
pf.to_excel("count.xlsx",sheet_name = "sheet1")

"统计癌症突变个数"
fileNameStr = 'mutation2.xlsx'
xl = pd.ExcelFile(fileNameStr)
mu_dat = xl.parse('COSMIC_filter')
mu_dat = mu_dat.drop_duplicates(subset=['LEGACY_MUTATION_ID'])
mu_dat.to_excel("filter.xlsx",sheet_name = "Sheet1",index = False)
res = getlistnum(list(mu_dat["disease"]))
pf = pd.Series(res)
pf.to_excel("count2.xlsx",sheet_name = "sheet1")

"统计突变位点的重要性"
fileNameStr = 'mutation2.xlsx'
xl = pd.ExcelFile(fileNameStr)
df1 = xl.parse("disorder-aamutation")
df2 = xl.parse("cancer-aamutation")
pd_dat = pd.merge(df1,df2,how = "outer")
res = getlistnum(list(pd_dat["aamutation"]))
pf = pd.Series(res)
pf.to_excel("count3.xlsx",sheet_name = "sheet1",index = False)

"合并癌症和神经性疾病列表"
fileNameStr = 'mutation2.xlsx'
xl = pd.ExcelFile(fileNameStr)
df1 = xl.parse("Clinvar_filter")
df2 = xl.parse("COSMIC_filter")
df3 = pd.merge(df1,df2,on = "aamutation")
df3.to_excel("merge_res.xlsx",sheet_name = "sheet1",index = False)


"提取protein.change的位点"
fileNameStr = 'mutation2.xlsx'
xl = pd.ExcelFile(fileNameStr)
df1 = xl.parse('res')
position = list()
for i in range(0,df1.count()[1]):
    pchange = df1["Protein.change"][i]
    a = "".join(list(filter(str.isdigit, pchange)))
    position.append(a)

df1["position"] = position
df1.to_excel("res_p.xlsx",sheet_name = "sheet1",index = False)

"合并RASopathy的aamutation和p.change列表"
fileNameStr = 'mutation2.xlsx'
xl = pd.ExcelFile(fileNameStr)
df1 = xl.parse("Clinvar_filter")
df2 = xl.parse("RAS")
df3 = pd.merge(df1,df2,on = "aamutation")
df3.to_excel("RAS_p.xlsx",sheet_name = "sheet1",index = False)

"合并NS的aamutation和p.change列表"
fileNameStr = 'mutation2.xlsx'
xl = pd.ExcelFile(fileNameStr)
df1 = xl.parse("Clinvar_filter")
df2 = xl.parse("NS")
df3 = pd.merge(df1,df2,on = "aamutation")
df3.to_excel("NS_p.xlsx",sheet_name = "sheet1",index = False)




