library("xlsx")
library(grid)
library(futile.logger)
library(VennDiagram)

setwd("SHP2/Data_Analysis")
#RC组
RC_mat <- read.xlsx("Table_S1.xlsx",2)
head(RC_mat)
#   POS SEQ protein_change cDNA_change      Type Domain
# 1   1   M           <NA>        <NA>      <NA>   <NA>
# 2   2   T          p.T2I      c.5C>T RASopathy   <NA>
# 3   3   S           <NA>        <NA>      <NA>   <NA>
# 4   4   R           <NA>        <NA>      <NA>   <NA>
# 5   5   R           <NA>        <NA>      <NA>   <NA>
# 6   6   W          p.W6C     c.18G>T    CANCER  SH2_1
RC_type <- as.data.frame(table(RC_mat$Type))
colnames(RC_type) <- c("Type","Count")
head(RC_type)
#         Type Count
# 1     CANCER   181
# 2 CANCER&RAS    64
# 3  RASopathy   127

#venn
p1 <- draw.pairwise.venn(
	area1 = 181+64,  #区域1的数
  	area2 = 127+64,   #区域2的数
  	cross.area = 64,  #交叉数
  	category = c("CANCER", "RASopathy"),#分类名称
  	fill = c("blue", "red"),#区域填充颜色
  	lty = "blank",  #区域边框线类型
  	cex = 2,        #区域内部数字的字体大小
  	cat.cex = 2,    #分类名称字体大小
  	cat.pos = c(285, 105), #分类名称在圆的位置，默认正上方，通过角度进行调整
  	cat.dist = 0.09,   #分类名称距离边的距离（可以为负数）
  	cat.just = list(c(-1, -1), c(1, 1)),  #分类名称的位置
  	ext.pos = 30,  #线的角度 默认是正上方12点位置
  	ext.dist = -0.05,   #外部线的距离
  	ext.length = 0.85,  #外部线长度
  	ext.line.lwd = 2,  #外部线的宽度
  	ext.line.lty = "dashed"   #外部线为虚线
  	)
p1 <- grid.draw(p1)
grid.newpage()

#NC组
NC_mat <- read.xlsx("Table_S1.xlsx",3)
head(NC_mat)
#   POS SEQ protein_change cDNA_change            Type Domain
# 1   1   M           <NA>        <NA>            <NA>   <NA>
# 2   2   T          p.T2I      c.5C>T Noonan syndrome   <NA>
# 3   3   S           <NA>        <NA>            <NA>   <NA>
# 4   4   R           <NA>        <NA>            <NA>   <NA>
# 5   5   R           <NA>        <NA>            <NA>   <NA>
# 6   6   W          p.W6C     c.18G>T          CANCER  SH2_1
NC_type <- as.data.frame(table(NC_mat$Type))
colnames(NC_type) <- c("Type","Count")
head(NC_type)
#              Type Count
# 1          CANCER   186
# 2       CANCER&NS    59
# 3 Noonan syndrome    69

#venn
p2 <- draw.pairwise.venn(
	area1 = 186+59,  #区域1的数
  	area2 = 59+69,   #区域2的数
  	cross.area = 59,  #交叉数
  	category = c("CANCER", "Noonan syndrome"),#分类名称
  	fill = c("blue", "red"),#区域填充颜色
  	lty = "blank",  #区域边框线类型
  	cex = 2,        #区域内部数字的字体大小
  	cat.cex = 2,    #分类名称字体大小
  	cat.pos = c(285, 105), #分类名称在圆的位置，默认正上方，通过角度进行调整
  	cat.dist = 0.09,   #分类名称距离边的距离（可以为负数）
  	cat.just = list(c(-1, -1), c(1, 1)),  #分类名称的位置
  	ext.pos = 30,  #线的角度 默认是正上方12点位置
  	ext.dist = -0.05,   #外部线的距离
  	ext.length = 0.85,  #外部线长度
  	ext.line.lwd = 2,  #外部线的宽度
  	ext.line.lty = "dashed"   #外部线为虚线
  	)
p2 <- grid.draw(p2)
grid.newpage()