library("xlsx")

setwd("SHP2/Data_Analysis")
S1_mat <- read.xlsx("Table_S1.xlsx",1)
head(S1_mat)
#   POS SEQ Domain Score        Si         MI
# 1   1   M   <NA>     8 0.3460374 0.08310654
# 2   2   T   <NA>     4 1.7203559 0.19447303
# 3   3   S   <NA>     7 0.6745083 0.12656604
# 4   4   R   <NA>     5 1.0843388 0.17519823
# 5   5   R   <NA>     6 0.6938581 0.14705145
# 6   6   W  SH2 1     7 0.0969861 0.08038977

#RC组
RC_mat <- read.xlsx("Table_S1.xlsx",2)
head(RC_mat)
#   POS SEQ protein_change cDNA_change      Type Domain
# 1   1   M           <NA>        <NA>      <NA>   <NA>
# 2   2   T          p.T2I      c.5C>T RASopathy   <NA>
# 3   3   S           <NA>        <NA>      <NA>   <NA>
# 4   4   R           <NA>        <NA>      <NA>   <NA>
# 5   5   R           <NA>        <NA>      <NA>   <NA>
# 6   6   W          p.W6C     c.18G>T    CANCER  SH2_1

#RASopathy
RCR <- subset(RC_mat,Type == "RASopathy")
head(RCR)
#    POS SEQ protein_change cDNA_change      Type Domain
# 2    2   T          p.T2I      c.5C>T RASopathy   <NA>
# 10  10   N         p.N10D     c.28A>G RASopathy  SH2_1
# 12  12   T         p.T12A     c.34A>G RASopathy  SH2_1
# 19  18   N         p.N18S     c.53A>G RASopathy  SH2_1
# 36  35   K         p.K35E    c.103A>G RASopathy  SH2_1
# 44  43   L         p.L43F    c.127C>T RASopathy  SH2_1
RCR <- merge(RCR,S1_mat[,c(1,4:6)],by = "POS")

#CANCER
RCC <- subset(RC_mat,Type == "CANCER")
head(RCC)
#    POS SEQ protein_change cDNA_change   Type Domain
# 6    6   W          p.W6C     c.18G>T CANCER  SH2_1
# 14  14   V         p.V14M     c.40G>A CANCER  SH2_1
# 16  16   A         p.A16T     c.46G>A CANCER  SH2_1
# 17  16   A         p.A16V     c.47C>T CANCER  SH2_1
# 26  25   V         p.V25I     c.73G>A CANCER  SH2_1
# 34  33   P         p.P33S     c.97C>T CANCER  SH2_1 
RCC <- merge(RCC,S1_mat[,c(1,4:6)],by = "POS")
#bind
RC_mat <- rbind(RCR,RCC)

write.xlsx(RC_mat, "SHP2_data.xlsx",sheetName = "RC",append = TRUE,showNA = FALSE)

#NC组
NC_mat <- read.xlsx("Table_S1.xlsx",3)
head(NC_mat)
#   POS SEQ protein_change cDNA_change            Type Domain
# 1   1   M           <NA>        <NA>            <NA>   <NA>
# 2   2   T          p.T2I      c.5C>T Noonan syndrome   <NA>
# 3   3   S           <NA>        <NA>            <NA>   <NA>
# 4   4   R           <NA>        <NA>            <NA>   <NA>
# 5   5   R           <NA>        <NA>            <NA>   <NA>
# 6   6   W          p.W6C     c.18G>T          CANCER  SH2_1
NCN <- subset(NC_mat,Type == "Noonan syndrome")
head(NCN)
# POS SEQ protein_change cDNA_change            Type Domain
# 2    2   T          p.T2I      c.5C>T Noonan syndrome   <NA>
# 19  18   N         p.N18S     c.53A>G Noonan syndrome  SH2_1
# 20  18   N         p.N18S     c.53A>G Noonan syndrome  SH2_1
# 24  22   T         p.T22A     c.64A>G Noonan syndrome  SH2_1
# 59  56   I         p.I56V    c.166A>G Noonan syndrome  SH2_1
# 60  56   I         p.I56T    c.167T>C Noonan syndrome  SH2_1
NCN <- merge(NCN,S1_mat[,c(1,4:6)],by = "POS")

#CANCER
NCC <- subset(NC_mat,Type == "CANCER")
head(NCC)
#    POS SEQ protein_change cDNA_change   Type Domain
# 6    6   W          p.W6C     c.18G>T CANCER  SH2_1
# 14  14   V         p.V14M     c.40G>A CANCER  SH2_1
# 16  16   A         p.A16T     c.46G>A CANCER  SH2_1
# 17  16   A         p.A16V     c.47C>T CANCER  SH2_1
# 27  25   V         p.V25I     c.73G>A CANCER  SH2_1
# 35  33   P         p.P33S     c.97C>T CANCER  SH2_1
NCC <- merge(NCC,S1_mat[,c(1,4:6)],by = "POS")
#bind
NC_mat <- rbind(NCN,NCC)

write.xlsx(NC_mat, "SHP2_data.xlsx",sheetName = "NC",append = TRUE,showNA = FALSE)

