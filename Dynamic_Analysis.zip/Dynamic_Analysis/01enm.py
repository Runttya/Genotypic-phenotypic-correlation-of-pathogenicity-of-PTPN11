import sys,os
# import time
from prody import *
#import prody
from pylab import *

list_file = 'pdb_list.txt'
pdb_path = 'all_result/RC/'
out_path = 'all_result/anm_msf/'

f_list = open(list_file, 'r')
    
for line in f_list:
    pdb_name = line.strip()
    print('\n' + pdb_name)
    pdb_file = pdb_path + pdb_name
    
    #structure = parsePDB(pdb_file)
    #calphas = structure.select('not ion and name CA')
    #print(str(calphas.numAtoms()) + ' nodes are selected.')

    #anm
    #anm = ANM(pdb_name)
    #anm.buildHessian(calphas)
    #anm.calcModes(n_modes=n_modes_n)
    
    #msf
    
#   msf_anm = calcSqFlucts(modes=anm[:10])
#   f_out_name = out_path + os.sep + pdb_name + '_anm_msf.txt'
#   savetxt(f_out_name, msf_anm, fmt='%.8e', delimiter=' ', newline='\n', header='', footer='', comments='')
#   close()

    ampar_ca = parsePDB(pdb_file, subset='ca')
    print(str(ampar_ca.numAtoms()) + ' nodes are selected.')
    anm_ampar = ANM(pdb_name)
    anm_ampar.buildHessian(ampar_ca)
    anm_ampar.calcModes('all')
    
    prs_mat, effectiveness, sensitivity = calcPerturbResponse(anm_ampar)
    
    f_out_name = out_path + os.sep + pdb_name + '_anm_eff.txt'
    savetxt(f_out_name, effectiveness, fmt='%.8e', delimiter=' ', newline='\n', header='', footer='', comments='')
    close()
    
    f_out_name = out_path + os.sep + pdb_name + '_anm_sen.txt'
    savetxt(f_out_name, sensitivity, fmt='%.8e', delimiter=' ', newline='\n', header='', footer='', comments='')
    close()
    

f_list.close()

