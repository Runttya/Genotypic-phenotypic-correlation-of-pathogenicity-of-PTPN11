library("xlsx")
library("ggplot2")
library("ggpubr")
library("gridExtra")
library("RColorBrewer")
library("patchwork")

setwd("SHP2/Dynamic_Analysis")
S1_mat <- read.xlsx("Table_S1.xlsx",1)
head(S1_mat)
#   POS SEQ Domain Score        Si         MI      RASA       MSF Effectiveness Sensitivity
# 1   1   M   <NA>     8 0.3460374 0.08310654 35.427400 11.469404      28.82540   0.3409062
# 2   2   T   <NA>     4 1.7203559 0.19447303 95.007500  9.543178      32.61030   0.2850602
# 3   3   S   <NA>     7 0.6745083 0.12656604 46.701600  9.979371      32.82278   0.3289758
# 4   4   R   <NA>     5 1.0843388 0.17519823  1.755030 10.943421      28.98066   0.3951870
# 5   5   R   <NA>     6 0.6938581 0.14705145 21.585600 12.790354      26.05801   0.4490971
# 6   6   W  SH2 1     7 0.0969861 0.08038977  0.657588 15.328404      21.48299   0.5373204

#RC
RC_mat <- read.xlsx("SHP2_data.xlsx",1)
head(RC_mat)
#   NUM POS SEQ protein_change cDNA_change      Type Domain Score        Si         MI       ΔΔG      RASA
# 1   1   2   T          p.T2I      c.5C>T RASopathy   <NA>     4 1.7203559 0.19447303  0.178354 95.007500
# 2   2  10   N         p.N10D     c.28A>G RASopathy  SH2_1     6 1.4419147 0.31591289  4.353530 13.753700
# 3   3  12   T         p.T12A     c.34A>G RASopathy  SH2_1     7 1.1196461 0.15424828  0.475647 36.936600
# 4   4  18   N         p.N18S     c.53A>G RASopathy  SH2_1     3 2.1819636 0.34615723 -0.176573 54.408800
# 5   5  35   K         p.K35E    c.103A>G RASopathy  SH2_1     5 1.3564694 0.26279907 -1.142700 51.944500
# 6   6  43   L         p.L43F    c.127C>T RASopathy  SH2_1     8 0.1726519 0.05485857  2.684760  0.141452
#       Degree Betweenness  Closeness
# 1 -0.0111473  0.05047757  0.6266855
# 2 -0.0111473  0.05047757 -0.7424476
# 3 -0.0111473  0.04966134 -0.7442245
# 4 -0.0111473  0.03602627 -0.3815926
# 5 -0.0111473  0.15392553 -1.5556249
# 6 -0.0111473 -0.22747229 -1.4904131

#合并
RC_mat<- merge(RC_mat,S1_mat[,c(1,8:10)],by = "POS")

write.xlsx(RC_mat, "SHP2_data.xlsx",sheetName = "DA",append = TRUE,showNA = FALSE)
#在excel中整理RC表

#柱状图
RC_mat <- read.xlsx("m_type.xlsx",1)
head(RC_mat)
#   NA. POS SEQ Domain Score        Si         MI      RASA       MSF Effectiveness Sensitivity   Type
# 1   1   1   M   <NA>     8 0.3460374 0.08310654 35.427400 11.469404      28.82540   0.3409062   <NA>
# 2   2   2   T   <NA>     4 1.7203559 0.19447303 95.007500  9.543178      32.61030   0.2850602    RAS
# 3   3   3   S   <NA>     7 0.6745083 0.12656604 46.701600  9.979371      32.82278   0.3289758   <NA>
# 4   4   4   R   <NA>     5 1.0843388 0.17519823  1.755030 10.943421      28.98066   0.3951870   <NA>
# 5   5   5   R   <NA>     6 0.6938581 0.14705145 21.585600 12.790354      26.05801   0.4490971   <NA>
# 6   6   6   W  SH2 1     7 0.0969861 0.08038977  0.657588 15.328404      21.48299   0.5373204 CANCER

#RC_mat <- subset(RC_mat,POS <= 500)

point_mat <- subset(RC_mat,Type != "NA")
head(point_mat)
#    NA. POS SEQ Domain Score        Si         MI      RASA       MSF Effectiveness Sensitivity   Type
# 2    2   2   T   <NA>     4 1.7203559 0.19447303 95.007500  9.543178     32.610301   0.2850602    RAS
# 6    6   6   W  SH2 1     7 0.0969861 0.08038977  0.657588 15.328404     21.482988   0.5373204 CANCER
# 10  10  10   N  SH2 1     6 1.4419147 0.31591289 13.753700 21.566318     12.074674   0.8247089    RAS
# 12  12  12   T  SH2 1     7 1.1196461 0.15424828 36.936600 29.140534      8.647312   1.0685560    RAS
# 14  14  14   V  SH2 1     3 1.7290894 0.29151016 69.758600 35.624986      6.976254   1.2440535 CANCER
# 16  16  16   A  SH2 1     9 0.1268547 0.04265571  0.000000 28.130999      9.677493   0.9818018 CANCER

p1 <- ggplot(RC_mat,aes(POS,log10(MSF)))+
  geom_bar(stat = 'identity',color = "#CCCCCC")+
  geom_point(data = point_mat,aes(x = POS,y = log10(MSF),color = Type),size = 3,shape = 17)+
  theme(legend.position = "top",legend.title=element_blank())
p1

p2 <- ggplot(RC_mat,aes(POS,Effectiveness))+
  geom_bar(stat = 'identity',color = "#CCCCCC")+
  geom_point(data = point_mat,aes(x = POS,y = Effectiveness,color = Type),size = 3,shape = 17)+
  theme(legend.position = "none")
p2

p3 <- ggplot(RC_mat,aes(POS,log10(Sensitivity)))+
  geom_bar(stat = 'identity',color = "#CCCCCC")+
  geom_point(data = point_mat,aes(x = POS,y = log10(Sensitivity),color = Type),size = 3,shape = 17)+
  theme(legend.position = "none")
p3

MSF_count <- dim(subset(RC_mat,MSF < median(RC_mat$MSF)))[1]/dim(RC_mat)[1]

pb <- ggplot(RC_mat,aes(x = Type,y = Count,fill = Type))+
      geom_bar(stat = 'identity',aes(fill = Domain),position = "fill")+
      theme(legend.position = "top",legend.title=element_blank())+
      coord_flip()

p1/p2/p3+
plot_annotation(tag_levels = "A")

#提琴图
RAS_mat <- read.xlsx("SHP2_data.xlsx",1)
#RAS_mat <- subset(RAS_mat,POS <= 500)

#将type转为factor
RAS_mat$Type <- as.factor(RAS_mat$Type)
#添加RAS各组间的比较
RAS_comparisons<-list(c("RASopathy","CANCER"))

RAS_mat$MSF <- log10(RAS_mat$MSF)
RAS_mat$Sensitivity <- log10(RAS_mat$Sensitivity)
#绘制MSF提琴图
p4 <- ggviolin(RAS_mat, x="Type", y="MSF", fill ="Type", add = "boxplot", add.params = list(fill="Type"))+ 
  stat_compare_means(comparisons = RAS_comparisons)+ 
  xlab("Type")+
  ylab("log10(MSF)")+
  guides(fill="none")+
  theme(axis.text.x =element_text(size = 10),
        axis.text.y =element_text(size = 15),
        axis.title.y = element_text(size = 20))
p4

#绘制effectiveness提琴图
p5 <- ggviolin(RAS_mat, x="Type", y="Effectiveness", fill ="Type", add = "boxplot", add.params = list(fill="Type"))+ 
  stat_compare_means(comparisons = RAS_comparisons)+ 
  xlab("Type")+
  ylab("Effectiveness")+
  guides(fill="none")+
  theme(axis.text.x =element_text(size = 10),
        axis.text.y =element_text(size = 15),
        axis.title.y = element_text(size = 20))
p5

#绘制sensitivity提琴图
p6 <- ggviolin(RAS_mat, x="Type", y="Sensitivity", fill ="Type", add = "boxplot", add.params = list(fill="Type"))+ 
  stat_compare_means(comparisons = RAS_comparisons)+ 
  xlab("Type")+
  ylab("log10(Sensitivity)")+
  guides(fill="none")+
  theme(axis.text.x =element_text(size = 10),
        axis.text.y =element_text(size = 15),
        axis.title.y = element_text(size = 20))
p6

p1/p2/p3/(p4+p5+p6)+
plot_layout(heights =c(1,1,1,2),widths = c(1,1,1))+
plot_annotation(tag_levels = "A")