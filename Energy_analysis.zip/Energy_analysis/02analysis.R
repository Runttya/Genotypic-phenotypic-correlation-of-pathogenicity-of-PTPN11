library("xlsx")
library(patchwork)
library(ggplot2)
library(ggpubr)
library(gridExtra)
library(RColorBrewer)

setwd("SHP2/Energy_analysis")

#RC组
RC_mat <- read.xlsx("SHP2_data.xlsx",1)
head(RC_mat)
#   NUM POS SEQ protein_change cDNA_change      Type Domain Score        Si         MI       ΔΔG
# 1   1   2   T          p.T2I      c.5C>T RASopathy   <NA>     4 1.7203559 0.19447303  0.178354
# 2   2  10   N         p.N10D     c.28A>G RASopathy  SH2_1     6 1.4419147 0.31591289  4.353530
# 3   3  12   T         p.T12A     c.34A>G RASopathy  SH2_1     7 1.1196461 0.15424828  0.475647
# 4   4  18   N         p.N18S     c.53A>G RASopathy  SH2_1     3 2.1819636 0.34615723 -0.176573
# 5   5  35   K         p.K35E    c.103A>G RASopathy  SH2_1     5 1.3564694 0.26279907 -1.142700
# 6   6  43   L         p.L43F    c.127C>T RASopathy  SH2_1     8 0.1726519 0.05485857  2.684760

#自由能变化提琴图
RC_mat$Type <- as.factor(RC_mat$Type)
RC_comparisons<-list(c("RASopathy","CANCER"))

p1 <- ggviolin(RC_mat, x="Type", y="ΔΔG", fill ="Type", add = "boxplot", add.params = list(fill="Type"))+ 
  stat_compare_means(comparisons = RC_comparisons)+ 
  xlab("Type")+
  ylab("ΔΔG")+
  guides(fill="none")+
  theme(axis.text.x =element_text(size = 10),
        axis.text.y =element_text(size = 15),
        axis.title.y = element_text(size = 20))
p1

#求每个位点的均值
meanG_mat <- aggregate(.~POS,data=RC_mat[,c("POS","Type","ΔΔG")],mean)
head(meanG_mat)
#   POS Type       ΔΔG
# 1   2    2  0.178354
# 2   6    1  4.484470
# 3  10    2  4.353530
# 4  12    2  0.475647
# 5  14    1 -0.672215
# 6  16    1  3.879440
for(i in 1:dim(meanG_mat)[1]){
	if(meanG_mat[i,"Type"] == 2)
		meanG_mat[i,"Type"] <- "RAS"
	else if(meanG_mat[i,"Type"] == 1)
		meanG_mat[i,"Type"] <- "CANCER"
	else 
		meanG_mat[i,"Type"] <- "RAS&CANCER"
}
head(meanG_mat)
#   POS   Type       ΔΔG
# 1   2    RAS  0.178354
# 2   6 CANCER  4.484470
# 3  10    RAS  4.353530
# 4  12    RAS  0.475647
# 5  14 CANCER -0.672215
# 6  16 CANCER  3.879440

#自由能分布柱状图
p2 <- ggplot(meanG_mat,aes(POS,ΔΔG,fill = Type))+
  geom_bar(stat = 'identity')+
  theme(legend.position = "top")
p2

#RASA
RC_mat <- read.xlsx("SHP2_data.xlsx",1)
head(RC_mat)
#   NUM POS SEQ protein_change cDNA_change      Type Domain Score        Si         MI       ΔΔG      RASA
# 1   1   2   T          p.T2I      c.5C>T RASopathy   <NA>     4 1.7203559 0.19447303  0.178354 95.007500
# 2   2  10   N         p.N10D     c.28A>G RASopathy  SH2_1     6 1.4419147 0.31591289  4.353530 13.753700
# 3   3  12   T         p.T12A     c.34A>G RASopathy  SH2_1     7 1.1196461 0.15424828  0.475647 36.936600
# 4   4  18   N         p.N18S     c.53A>G RASopathy  SH2_1     3 2.1819636 0.34615723 -0.176573 54.408800
# 5   5  35   K         p.K35E    c.103A>G RASopathy  SH2_1     5 1.3564694 0.26279907 -1.142700 51.944500
# 6   6  43   L         p.L43F    c.127C>T RASopathy  SH2_1     8 0.1726519 0.05485857  2.684760  0.141452

#提琴图
RC_mat$Type <- as.factor(RC_mat$Type)
RC_comparisons<-list(c("RASopathy","CANCER"))
p3 <- ggviolin(RC_mat, x="Type", y="RASA", fill ="Type", add = "boxplot", add.params = list(fill="Type"))+ 
  stat_compare_means(comparisons = RC_comparisons)+ 
  xlab("Type")+
  ylab("RASA")+
  guides(fill="none")+
  theme(axis.text.x =element_text(size = 10),
        axis.text.y =element_text(size = 15),
        axis.title.y = element_text(size = 20))
p3

#RASA分布柱状图
#m_type.xlsx添加RASA列
RC_mat <- read.xlsx("m_type.xlsx",1)
head(RC_mat)
#   NA. POS SEQ Domain Score        Si         MI      RASA   Type
# 1   1   1   M   <NA>     8 0.3460374 0.08310654 35.427400   <NA>
# 2   2   2   T   <NA>     4 1.7203559 0.19447303 95.007500    RAS
# 3   3   3   S   <NA>     7 0.6745083 0.12656604 46.701600   <NA>
# 4   4   4   R   <NA>     5 1.0843388 0.17519823  1.755030   <NA>
# 5   5   5   R   <NA>     6 0.6938581 0.14705145 21.585600   <NA>
# 6   6   6   W  SH2 1     7 0.0969861 0.08038977  0.657588 CANCER
point_mat <- subset(RC_mat,Type != "NA")
head(point_mat)
#    NA. POS SEQ Domain Score        Si         MI      RASA   Type
# 2    2   2   T   <NA>     4 1.7203559 0.19447303 95.007500    RAS
# 6    6   6   W  SH2 1     7 0.0969861 0.08038977  0.657588 CANCER
# 10  10  10   N  SH2 1     6 1.4419147 0.31591289 13.753700    RAS
# 12  12  12   T  SH2 1     7 1.1196461 0.15424828 36.936600    RAS
# 14  14  14   V  SH2 1     3 1.7290894 0.29151016 69.758600 CANCER
# 16  16  16   A  SH2 1     9 0.1268547 0.04265571  0.000000 CANCER
p4 <- ggplot(RC_mat,aes(POS,RASA))+
  geom_bar(stat = 'identity',color = "#CCCCCC")+
  geom_point(data = point_mat,aes(x = POS,y = RASA,color = Type),size = 3,shape = 17)+
  theme(legend.position = "top",legend.title=element_blank())+
  geom_line(y = 5,color = "yellow")+
  geom_line(y = 30,color = "green")
p4

((p2/p4)|p1|p3)+
plot_layout(widths =c(3,1,1))+
plot_annotation(tag_levels = "A")