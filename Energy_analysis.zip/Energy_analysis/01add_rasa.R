library("xlsx")
#RC
setwd("SHP2/Energy_analysis")
S1_mat <- read.xlsx("Table_S1.xlsx",1)
head(S1_mat)
#   POS SEQ Domain Score        Si         MI
# 1   1   M   <NA>     8 0.3460374 0.08310654
# 2   2   T   <NA>     4 1.7203559 0.19447303
# 3   3   S   <NA>     7 0.6745083 0.12656604
# 4   4   R   <NA>     5 1.0843388 0.17519823
# 5   5   R   <NA>     6 0.6938581 0.14705145
# 6   6   W  SH2 1     7 0.0969861 0.08038977

#读取xml文件
setwd("SHP2/Energy_analysis/PSAIA")
library("XML")
doc <-  xmlParse("SHP2_rasa.xml")
root=xmlRoot(doc)
#循环取rasa的数据
RASA <- c()
for(i in S1_mat$POS){
	res_rasa <- as.numeric(xmlToList(root[[8]][[1]][[3]][[i]][[4]][[1]]))
	RASA <- c(RASA,res_rasa)
}
length(RASA)
#给总表添加RASA
S1_mat[,"RASA"] <- RASA
head(S1_mat)
#   POS SEQ Domain Score        Si         MI      RASA
# 1   1   M   <NA>     8 0.3460374 0.08310654 35.427400
# 2   2   T   <NA>     4 1.7203559 0.19447303 95.007500
# 3   3   S   <NA>     7 0.6745083 0.12656604 46.701600
# 4   4   R   <NA>     5 1.0843388 0.17519823  1.755030
# 5   5   R   <NA>     6 0.6938581 0.14705145 21.585600
# 6   6   W  SH2 1     7 0.0969861 0.08038977  0.657588
write.xlsx(S1_mat, "SHP2_data1.xlsx",sheetName = "S1",append = TRUE,showNA = FALSE)

#RC组
RC_mat <- read.xlsx("Table_S1.xlsx",2)
#RASopathy
RCR <- subset(RC_mat,Type == "RASopathy")
head(RCR)
#    POS SEQ protein_change cDNA_change      Type Domain
# 2    2   T          p.T2I      c.5C>T RASopathy   <NA>
# 10  10   N         p.N10D     c.28A>G RASopathy  SH2_1
# 12  12   T         p.T12A     c.34A>G RASopathy  SH2_1
# 19  18   N         p.N18S     c.53A>G RASopathy  SH2_1
# 36  35   K         p.K35E    c.103A>G RASopathy  SH2_1
# 44  43   L         p.L43F    c.127C>T RASopathy  SH2_1

#RCR列全选，S1选POS(用于merge),Si,MI,RASA列
RCR <- merge(RCR,S1_mat[,c(1,4:7)],by = "POS")
head(RCR)
#   POS SEQ protein_change cDNA_change      Type Domain Score        Si         MI      RASA
# 1   2   T          p.T2I      c.5C>T RASopathy   <NA>     4 1.7203559 0.19447303 95.007500
# 2  10   N         p.N10D     c.28A>G RASopathy  SH2_1     6 1.4419147 0.31591289 13.753700
# 3  12   T         p.T12A     c.34A>G RASopathy  SH2_1     7 1.1196461 0.15424828 36.936600
# 4  18   N         p.N18S     c.53A>G RASopathy  SH2_1     3 2.1819636 0.34615723 54.408800
# 5  35   K         p.K35E    c.103A>G RASopathy  SH2_1     5 1.3564694 0.26279907 51.944500
# 6  43   L         p.L43F    c.127C>T RASopathy  SH2_1     8 0.1726519 0.05485857  0.141452

#CANCER
RCC <- subset(RC_mat,Type == "CANCER")
head(RCC)
#    POS SEQ protein_change cDNA_change   Type Domain
# 6    6   W          p.W6C     c.18G>T CANCER  SH2_1
# 14  14   V         p.V14M     c.40G>A CANCER  SH2_1
# 16  16   A         p.A16T     c.46G>A CANCER  SH2_1
# 17  16   A         p.A16V     c.47C>T CANCER  SH2_1
# 26  25   V         p.V25I     c.73G>A CANCER  SH2_1
# 34  33   P         p.P33S     c.97C>T CANCER  SH2_1
RCC <- merge(RCC,S1_mat[,c(1,4:7)],by = "POS")
head(RCC)
#   POS SEQ protein_change cDNA_change   Type Domain Score        Si         MI      RASA
# 1   6   W          p.W6C     c.18G>T CANCER  SH2_1     7 0.0969861 0.08038977  0.657588
# 2  14   V         p.V14M     c.40G>A CANCER  SH2_1     3 1.7290894 0.29151016 69.758600
# 3  16   A         p.A16T     c.46G>A CANCER  SH2_1     9 0.1268547 0.04265571  0.000000
# 4  16   A         p.A16V     c.47C>T CANCER  SH2_1     9 0.1268547 0.04265571  0.000000
# 5  25   V         p.V25I     c.73G>A CANCER  SH2_1     4 1.6669482 0.28408907 57.417600
# 6  33   P         p.P33S     c.97C>T CANCER  SH2_1     9 0.1268547 0.04931259 11.073300

#bind
RC_mat <- rbind(RCR,RCC)
head(RC_mat)
#   POS SEQ protein_change cDNA_change      Type Domain Score        Si         MI      RASA
# 1   2   T          p.T2I      c.5C>T RASopathy   <NA>     4 1.7203559 0.19447303 95.007500
# 2  10   N         p.N10D     c.28A>G RASopathy  SH2_1     6 1.4419147 0.31591289 13.753700
# 3  12   T         p.T12A     c.34A>G RASopathy  SH2_1     7 1.1196461 0.15424828 36.936600
# 4  18   N         p.N18S     c.53A>G RASopathy  SH2_1     3 2.1819636 0.34615723 54.408800
# 5  35   K         p.K35E    c.103A>G RASopathy  SH2_1     5 1.3564694 0.26279907 51.944500
# 6  43   L         p.L43F    c.127C>T RASopathy  SH2_1     8 0.1726519 0.05485857  0.141452

write.xlsx(RC_mat, "SHP2_data1.xlsx",sheetName = "RC",append = TRUE,showNA = FALSE)

#NC组
NC_mat <- read.xlsx("Table_S1.xlsx",3)
#Noonan syndrome
NCN <- subset(NC_mat,Type == "Noonan syndrome")
head(NCN)
#    POS SEQ protein_change cDNA_change            Type Domain
# 2    2   T          p.T2I      c.5C>T Noonan syndrome   <NA>
# 19  18   N         p.N18S     c.53A>G Noonan syndrome  SH2_1
# 20  18   N         p.N18S     c.53A>G Noonan syndrome  SH2_1
# 24  22   T         p.T22A     c.64A>G Noonan syndrome  SH2_1
# 59  56   I         p.I56V    c.166A>G Noonan syndrome  SH2_1
# 60  56   I         p.I56T    c.167T>C Noonan syndrome  SH2_1
#NCN列全选，S1选POS(用于merge),Si,MI,RASA列
NCN <- merge(NCN,S1_mat[,c(1,4:7)],by = "POS")
head(NCN)
#   POS SEQ protein_change cDNA_change            Type Domain Score       Si         MI      RASA
# 1   2   T          p.T2I      c.5C>T Noonan syndrome   <NA>     4 1.720356 0.19447303 95.007500
# 2  18   N         p.N18S     c.53A>G Noonan syndrome  SH2_1     3 2.181964 0.34615723 54.408800
# 3  18   N         p.N18S     c.53A>G Noonan syndrome  SH2_1     3 2.181964 0.34615723 54.408800
# 4  22   T         p.T22A     c.64A>G Noonan syndrome  SH2_1     4 1.886859 0.31918443 79.954100
# 5  56   I         p.I56V    c.166A>G Noonan syndrome  SH2_1     9 0.233137 0.04711866  0.534083
# 6  56   I         p.I56T    c.167T>C Noonan syndrome  SH2_1     9 0.233137 0.04711866  0.534083

#CANCER
NCC <- subset(NC_mat,Type == "CANCER")
head(NCC)
#    POS SEQ protein_change cDNA_change   Type Domain
# 6    6   W          p.W6C     c.18G>T CANCER  SH2_1
# 14  14   V         p.V14M     c.40G>A CANCER  SH2_1
# 16  16   A         p.A16T     c.46G>A CANCER  SH2_1
# 17  16   A         p.A16V     c.47C>T CANCER  SH2_1
# 27  25   V         p.V25I     c.73G>A CANCER  SH2_1
# 35  33   P         p.P33S     c.97C>T CANCER  SH2_1
NCC <- merge(NCC,S1_mat[,c(1,4:7)],by = "POS")
head(NCC)
#   POS SEQ protein_change cDNA_change   Type Domain Score        Si         MI      RASA
# 1   6   W          p.W6C     c.18G>T CANCER  SH2_1     7 0.0969861 0.08038977  0.657588
# 2  14   V         p.V14M     c.40G>A CANCER  SH2_1     3 1.7290894 0.29151016 69.758600
# 3  16   A         p.A16T     c.46G>A CANCER  SH2_1     9 0.1268547 0.04265571  0.000000
# 4  16   A         p.A16V     c.47C>T CANCER  SH2_1     9 0.1268547 0.04265571  0.000000
# 5  25   V         p.V25I     c.73G>A CANCER  SH2_1     4 1.6669482 0.28408907 57.417600
# 6  33   P         p.P33S     c.97C>T CANCER  SH2_1     9 0.1268547 0.04931259 11.073300

#bind
NC_mat <- rbind(NCN,NCC)
head(NC_mat)
#   POS SEQ protein_change cDNA_change            Type Domain Score       Si         MI      RASA
# 1   2   T          p.T2I      c.5C>T Noonan syndrome   <NA>     4 1.720356 0.19447303 95.007500
# 2  18   N         p.N18S     c.53A>G Noonan syndrome  SH2_1     3 2.181964 0.34615723 54.408800
# 3  18   N         p.N18S     c.53A>G Noonan syndrome  SH2_1     3 2.181964 0.34615723 54.408800
# 4  22   T         p.T22A     c.64A>G Noonan syndrome  SH2_1     4 1.886859 0.31918443 79.954100
# 5  56   I         p.I56V    c.166A>G Noonan syndrome  SH2_1     9 0.233137 0.04711866  0.534083
# 6  56   I         p.I56T    c.167T>C Noonan syndrome  SH2_1     9 0.233137 0.04711866  0.534083
write.xlsx(NC_mat, "SHP2_data1.xlsx",sheetName = "NC",append = TRUE,showNA = FALSE)

#处理完后将SHP2_data1.xlsx合并入SHP2_data.xlsx和Table_S1.xlsx中


